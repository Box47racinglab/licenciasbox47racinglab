# Box47racinglab
Sistema de licencias virtuales estilo F1 para simuladores
